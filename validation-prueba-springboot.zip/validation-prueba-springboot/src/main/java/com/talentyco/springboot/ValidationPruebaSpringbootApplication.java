package com.talentyco.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationPruebaSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationPruebaSpringbootApplication.class, args);
	}

}
